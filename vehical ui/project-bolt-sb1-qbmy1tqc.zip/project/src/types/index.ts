export interface User {
  id: string;
  email: string;
  name: string;
  role: 'Admin' | 'Valuator';
}

export interface Vehicle {
  id: string;
  make: string;
  model: string;
  year: number;
  transmission: string;
  fuelType: string;
  engineCC: number;
  mileage: number;
  systemPrice: number;
  manualPrice?: number;
  mapModelName?: string;
  lastUpdated: Date;
  updatedBy?: string;
}

export interface UnregisteredVehicle {
  id: string;
  make: string;
  model: string;
  year?: number;
  transmission?: string;
  fuelType?: string;
  engineCC?: number;
  mileage?: number;
  price?: number;
  status: 'pending' | 'mapped' | 'rejected';
  createdAt: Date;
}

export interface ModelMapping {
  id: string;
  originalModel: string;
  mapModelName: string;
  make: string;
  confidence: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface PriceChangeLog {
  id: string;
  vehicleId: string;
  oldPrice: number;
  newPrice: number;
  reason: string;
  changedBy: string;
  changedAt: Date;
  vehicleInfo: string;
}

export interface DashboardStats {
  totalRegisteredVehicles: number;
  totalUnregisteredEntries: number;
  totalMappedModels: number;
  totalPriceChanges: number;
  highestPrice: { amount: number; model: string };
  lowestPrice: { amount: number; model: string };
  recentlyEdited: Vehicle[];
  mostOverridden: { model: string; count: number }[];
}