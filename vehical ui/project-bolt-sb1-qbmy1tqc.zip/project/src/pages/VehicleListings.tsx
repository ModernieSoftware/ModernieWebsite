import React, { useState } from 'react';
import { Edit, Eye, History, DollarSign } from 'lucide-react';
import DataTable from '../components/ui/DataTable';
import { useData } from '../contexts/DataContext';
import { Vehicle } from '../types';
import { formatCurrency } from '../utils/format';
import { useAuth } from '../contexts/AuthContext';
import PriceEditModal from '../components/modals/PriceEditModal';

const VehicleListings: React.FC = () => {
  const { vehicles } = useData();
  const { user } = useAuth();
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const [showPriceModal, setShowPriceModal] = useState(false);

  const columns = [
    {
      key: 'make',
      header: 'Make',
      sortable: true
    },
    {
      key: 'model',
      header: 'Model',
      sortable: true
    },
    {
      key: 'year',
      header: 'Year',
      sortable: true
    },
    {
      key: 'transmission',
      header: 'Transmission'
    },
    {
      key: 'fuelType',
      header: 'Fuel Type'
    },
    {
      key: 'engineCC',
      header: 'Engine (CC)',
      sortable: true,
      render: (vehicle: Vehicle) => vehicle.engineCC.toLocaleString()
    },
    {
      key: 'mileage',
      header: 'Mileage (km)',
      sortable: true,
      render: (vehicle: Vehicle) => vehicle.mileage.toLocaleString()
    },
    {
      key: 'mapModelName',
      header: 'Mapped Model',
      render: (vehicle: Vehicle) => (
        <span className="text-blue-600 font-medium">
          {vehicle.mapModelName || '-'}
        </span>
      )
    },
    {
      key: 'systemPrice',
      header: 'System Price',
      sortable: true,
      render: (vehicle: Vehicle) => (
        <span className="font-mono text-sm">
          {formatCurrency(vehicle.systemPrice)}
        </span>
      )
    },
    {
      key: 'manualPrice',
      header: 'Manual Price',
      sortable: true,
      render: (vehicle: Vehicle) => (
        <div className="flex items-center space-x-2">
          <span className={`font-mono text-sm ${vehicle.manualPrice ? 'text-orange-600 font-medium' : 'text-slate-400'}`}>
            {vehicle.manualPrice ? formatCurrency(vehicle.manualPrice) : '-'}
          </span>
          {vehicle.manualPrice && (
            <span className="bg-orange-100 text-orange-800 text-xs px-2 py-1 rounded-full">
              Override
            </span>
          )}
        </div>
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (vehicle: Vehicle) => (
        <div className="flex items-center space-x-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setSelectedVehicle(vehicle);
              setShowPriceModal(true);
            }}
            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
            title="Edit Price"
          >
            <Edit className="w-4 h-4" />
          </button>
          <button
            onClick={(e) => e.stopPropagation()}
            className="p-2 text-slate-600 hover:bg-slate-50 rounded-lg transition-colors"
            title="View Details"
          >
            <Eye className="w-4 h-4" />
          </button>
          <button
            onClick={(e) => e.stopPropagation()}
            className="p-2 text-slate-600 hover:bg-slate-50 rounded-lg transition-colors"
            title="View History"
          >
            <History className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Registered Vehicles</h1>
          <p className="text-slate-600 mt-1">Manage vehicle listings and pricing</p>
        </div>
        <div className="flex items-center space-x-2">
          <DollarSign className="w-5 h-5 text-slate-400" />
          <span className="text-sm text-slate-600">
            {vehicles.length} vehicles
          </span>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h3 className="text-lg font-semibold text-slate-900 mb-4">Filters</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <select className="border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            <option value="">All Makes</option>
            <option value="Toyota">Toyota</option>
            <option value="Honda">Honda</option>
            <option value="BMW">BMW</option>
          </select>
          
          <select className="border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            <option value="">All Fuel Types</option>
            <option value="Petrol">Petrol</option>
            <option value="Hybrid">Hybrid</option>
            <option value="Electric">Electric</option>
          </select>
          
          <select className="border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            <option value="">All Transmissions</option>
            <option value="Manual">Manual</option>
            <option value="Automatic">Automatic</option>
            <option value="CVT">CVT</option>
          </select>
          
          <input
            type="number"
            placeholder="Year from"
            className="border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* Data Table */}
      <DataTable
        data={vehicles}
        columns={columns}
        searchable
        searchPlaceholder="Search vehicles..."
        onRowClick={(vehicle) => {
          setSelectedVehicle(vehicle);
          // Handle row click if needed
        }}
      />

      {/* Price Edit Modal */}
      {showPriceModal && selectedVehicle && (
        <PriceEditModal
          vehicle={selectedVehicle}
          isOpen={showPriceModal}
          onClose={() => {
            setShowPriceModal(false);
            setSelectedVehicle(null);
          }}
        />
      )}
    </div>
  );
};

export default VehicleListings;