import React, { useState } from 'react';
import { Plus, Edit, Trash2, Upload, Download, GitBranch } from 'lucide-react';
import DataTable from '../components/ui/DataTable';
import { useData } from '../contexts/DataContext';
import { ModelMapping } from '../types';

const ModelMappingPage: React.FC = () => {
  const { modelMappings, addModelMapping, updateModelMapping } = useData();
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingMapping, setEditingMapping] = useState<ModelMapping | null>(null);
  const [newMapping, setNewMapping] = useState({
    originalModel: '',
    mapModelName: '',
    make: '',
    confidence: 0.95
  });

  const handleAddMapping = () => {
    addModelMapping(newMapping);
    setNewMapping({
      originalModel: '',
      mapModelName: '',
      make: '',
      confidence: 0.95
    });
    setShowAddModal(false);
  };

  const handleEditMapping = (mapping: ModelMapping) => {
    setEditingMapping(mapping);
    setNewMapping({
      originalModel: mapping.originalModel,
      mapModelName: mapping.mapModelName,
      make: mapping.make,
      confidence: mapping.confidence
    });
    setShowAddModal(true);
  };

  const handleUpdateMapping = () => {
    if (editingMapping) {
      updateModelMapping(editingMapping.id, newMapping);
      setEditingMapping(null);
      setNewMapping({
        originalModel: '',
        mapModelName: '',
        make: '',
        confidence: 0.95
      });
      setShowAddModal(false);
    }
  };

  const columns = [
    {
      key: 'make',
      header: 'Make',
      sortable: true
    },
    {
      key: 'originalModel',
      header: 'Original Model',
      sortable: true
    },
    {
      key: 'mapModelName',
      header: 'Mapped Model Name',
      sortable: true,
      render: (mapping: ModelMapping) => (
        <span className="font-medium text-blue-600">{mapping.mapModelName}</span>
      )
    },
    {
      key: 'confidence',
      header: 'Confidence',
      sortable: true,
      render: (mapping: ModelMapping) => (
        <div className="flex items-center space-x-2">
          <div className="w-16 bg-slate-200 rounded-full h-2">
            <div 
              className="bg-green-500 h-2 rounded-full" 
              style={{ width: `${mapping.confidence * 100}%` }}
            />
          </div>
          <span className="text-sm font-medium">{(mapping.confidence * 100).toFixed(0)}%</span>
        </div>
      )
    },
    {
      key: 'updatedAt',
      header: 'Last Updated',
      sortable: true,
      render: (mapping: ModelMapping) => 
        new Date(mapping.updatedAt).toLocaleDateString()
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (mapping: ModelMapping) => (
        <div className="flex items-center space-x-2">
          <button
            onClick={() => handleEditMapping(mapping)}
            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
            title="Edit Mapping"
          >
            <Edit className="w-4 h-4" />
          </button>
          <button
            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
            title="Delete Mapping"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Model Mapping</h1>
          <p className="text-slate-600 mt-1">Manage vehicle model mappings and standardization</p>
        </div>
        <div className="flex items-center space-x-3">
          <button className="flex items-center space-x-2 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50">
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">Export</span>
          </button>
          <button className="flex items-center space-x-2 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50">
            <Upload className="w-4 h-4" />
            <span className="hidden sm:inline">Import</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Add Mapping</span>
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-600 text-sm font-medium">Total Mappings</p>
              <p className="text-2xl font-bold text-slate-900 mt-1">{modelMappings.length}</p>
            </div>
            <div className="bg-blue-500 p-3 rounded-lg">
              <GitBranch className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-600 text-sm font-medium">High Confidence</p>
              <p className="text-2xl font-bold text-slate-900 mt-1">
                {modelMappings.filter(m => m.confidence > 0.9).length}
              </p>
            </div>
            <div className="bg-green-500 p-3 rounded-lg">
              <GitBranch className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-600 text-sm font-medium">Unique Makes</p>
              <p className="text-2xl font-bold text-slate-900 mt-1">
                {new Set(modelMappings.map(m => m.make)).size}
              </p>
            </div>
            <div className="bg-purple-500 p-3 rounded-lg">
              <GitBranch className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Data Table */}
      <DataTable
        data={modelMappings}
        columns={columns}
        searchable
        searchPlaceholder="Search model mappings..."
      />

      {/* Add/Edit Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-md w-full">
            <div className="flex items-center justify-between p-6 border-b border-slate-200">
              <h2 className="text-xl font-bold text-slate-900">
                {editingMapping ? 'Edit Mapping' : 'Add New Mapping'}
              </h2>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setEditingMapping(null);
                  setNewMapping({
                    originalModel: '',
                    mapModelName: '',
                    make: '',
                    confidence: 0.95
                  });
                }}
                className="p-2 hover:bg-slate-100 rounded-lg"
              >
                ×
              </button>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Make</label>
                <input
                  type="text"
                  value={newMapping.make}
                  onChange={(e) => setNewMapping(prev => ({ ...prev, make: e.target.value }))}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Toyota"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Original Model</label>
                <input
                  type="text"
                  value={newMapping.originalModel}
                  onChange={(e) => setNewMapping(prev => ({ ...prev, originalModel: e.target.value }))}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Prius"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Mapped Model Name</label>
                <input
                  type="text"
                  value={newMapping.mapModelName}
                  onChange={(e) => setNewMapping(prev => ({ ...prev, mapModelName: e.target.value }))}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Toyota Prius Gen 4"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Confidence ({(newMapping.confidence * 100).toFixed(0)}%)
                </label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={newMapping.confidence}
                  onChange={(e) => setNewMapping(prev => ({ ...prev, confidence: parseFloat(e.target.value) }))}
                  className="w-full"
                />
              </div>
              
              <div className="flex space-x-3 pt-4">
                <button
                  onClick={() => {
                    setShowAddModal(false);
                    setEditingMapping(null);
                    setNewMapping({
                      originalModel: '',
                      mapModelName: '',
                      make: '',
                      confidence: 0.95
                    });
                  }}
                  className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  onClick={editingMapping ? handleUpdateMapping : handleAddMapping}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  {editingMapping ? 'Update' : 'Add'} Mapping
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ModelMappingPage;